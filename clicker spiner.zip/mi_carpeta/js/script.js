const menuScreen = document.getElementById('menuScreen');
const loadingScreen = document.getElementById('loadingScreen');
const gameApp = document.getElementById('gameApp');
const startButton = document.getElementById('startButton');
const modeToggleButton = document.getElementById('modeToggle');
const loadingFill = document.getElementById('loadingFill');
const spinner = document.getElementById('spinner');
const scoreElement = document.getElementById('score');
const powerElement = document.getElementById('power');
const autoElement = document.getElementById('auto');
const storeList = document.getElementById('storeList');
const milestoneInfo = document.getElementById('milestoneInfo');
const timerValue = document.getElementById('timerValue');
const toggleStoreButton = document.getElementById('toggleStore');
const storePanel = document.getElementById('storePanel');
const storeContent = document.getElementById('storeContent');
const cpsValue = document.getElementById('cpsValue');

const state = {
  points: 0,
  clickPower: 1,
  autoIncome: 0,
  extraMultiplier: 0,
  activeMultiplierIndex: 0,
  countdown: 60,
  storeOpen: true,
  clickTimes: [],
  totalClicks: 0,
  sessionStartedAt: performance.now(),
  controlMode: 'pc',
};

const multiplierCycle = [1, 2, 3, 4, 5, 6, 7, 8, 10, 12, 14, 16, 18, 21, 24, 28, 32, 40];

const shopItems = [
  {
    id: 'power',
    name: 'Poder extra',
    baseCost: 25,
    description: 'Aumenta tu clic en +1',
    level: 0,
  },
  {
    id: 'auto',
    name: 'Auto clic',
    baseCost: 60,
    description: 'Gana +1 punto por segundo',
    level: 0,
  },
  {
    id: 'multi',
    name: 'Multiplicador',
    baseCost: 120,
    description: 'Aumenta el bonus global en +1x',
    level: 0,
  },
];

function formatNumber(value) {
  return Math.floor(value).toLocaleString('es-MX');
}

function getCurrentMultiplier() {
  return multiplierCycle[state.activeMultiplierIndex] * (1 + state.extraMultiplier);
}

function getItemCost(item) {
  return Math.round(item.baseCost * Math.pow(1.6, item.level));
}

function updateMilestoneInfo() {
  const currentMultiplier = getCurrentMultiplier();
  milestoneInfo.textContent = `Multiplicador actual: ${currentMultiplier}x · Los multiplicadores cambian cada 60 segundos.`;
}

function updateTimer() {
  timerValue.textContent = state.countdown;
}

function applyMode() {
  document.body.dataset.mode = state.controlMode;
  modeToggleButton.textContent = state.controlMode === 'pc' ? 'Cambiar a móvil' : 'Cambiar a PC';
}

function updateCps() {
  const now = performance.now();

  while (state.clickTimes.length && now - state.clickTimes[0] > 1000) {
    state.clickTimes.shift();
  }

  const currentClicks = Math.min(state.clickTimes.length, 99);
  const elapsedSeconds = Math.max((now - state.sessionStartedAt) / 1000, 1);
  const averageClicks = Math.floor(state.totalClicks / elapsedSeconds);

  cpsValue.textContent = `${String(currentClicks).padStart(2, '0')}/${String(averageClicks).padStart(2, '0')}`;
}

function updateStats() {
  const totalPower = state.clickPower * getCurrentMultiplier();

  scoreElement.textContent = formatNumber(state.points);
  powerElement.textContent = `${formatNumber(totalPower)}x`;
  autoElement.textContent = `${formatNumber(state.autoIncome)}/s`;
  updateMilestoneInfo();
  updateTimer();
}

function addPoints(amount) {
  state.points += amount;
  updateStats();
}

function renderStore() {
  storeList.innerHTML = shopItems
    .map((item) => {
      const cost = getItemCost(item);
      const isDisabled = state.points < cost;

      return `
        <li class="store-item">
          <div>
            <strong>${item.name}</strong>
            <p>${item.description} · Nivel ${item.level}</p>
          </div>
          <button data-id="${item.id}" ${isDisabled ? 'disabled' : ''}>${cost} pts</button>
        </li>
      `;
    })
    .join('');

  storeList.querySelectorAll('button').forEach((button) => {
    button.addEventListener('click', () => {
      const item = shopItems.find((entry) => entry.id === button.dataset.id);
      const cost = getItemCost(item);

      if (state.points < cost) {
        return;
      }

      state.points -= cost;
      item.level += 1;

      if (item.id === 'power') {
        state.clickPower += 1;
      }

      if (item.id === 'auto') {
        state.autoIncome += 1;
      }

      if (item.id === 'multi') {
        state.extraMultiplier += 1;
      }

      updateStats();
      renderStore();
    });
  });
}

function toggleStorePanel() {
  state.storeOpen = !state.storeOpen;
  storePanel.classList.toggle('is-collapsed', !state.storeOpen);
  toggleStoreButton.textContent = state.storeOpen ? 'Cerrar tienda' : 'Editar tienda';
  toggleStoreButton.setAttribute('aria-expanded', String(state.storeOpen));
}

spinner.addEventListener('click', () => {
  state.clickTimes.push(performance.now());
  state.totalClicks += 1;
  updateCps();

  const clickGain = state.clickPower * getCurrentMultiplier();
  addPoints(clickGain);
  renderStore();
});

setInterval(() => {
  if (state.autoIncome > 0) {
    addPoints(state.autoIncome * getCurrentMultiplier());
  }

  updateCps();
}, 1000);

setInterval(() => {
  state.countdown -= 1;

  if (state.countdown <= 0) {
    state.activeMultiplierIndex = (state.activeMultiplierIndex + 1) % multiplierCycle.length;
    state.countdown = 60;
    updateStats();
    return;
  }

  updateTimer();
}, 1000);

toggleStoreButton.addEventListener('click', toggleStorePanel);

modeToggleButton.addEventListener('click', () => {
  state.controlMode = state.controlMode === 'pc' ? 'mobile' : 'pc';
  applyMode();
});

startButton.addEventListener('click', () => {
  menuScreen.classList.add('hidden');
  loadingScreen.classList.remove('hidden');

  let progress = 0;
  const loadingInterval = setInterval(() => {
    progress += 10;
    loadingFill.style.width = `${progress}%`;

    if (progress >= 100) {
      clearInterval(loadingInterval);

      setTimeout(() => {
        loadingScreen.classList.add('hidden');
        gameApp.classList.remove('hidden');
      }, 300);
    }
  }, 120);
});

applyMode();
updateStats();
renderStore();
